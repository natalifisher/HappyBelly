// TTGO manual: http://www.lilygo.cn/prod_view.aspx?Id=1126
// shows which are input only (might be wrong idk): https://randomnerdtutorials.com/esp32-pinout-reference-gpios/
// Check which pins are input only! available online

#include <Arduino.h>
#include "gyro_sensor.h"
#include "weight_sensor.h"
#include "buzzer.h"
#include "humidity_sensor.h"
#include "light_sensor.h"
#include "lights.h"
// #include "feeding.h"
#include "constants.h"
// #include "feeding.h"
#include "servo_sensor.h"
#include "display.h"
#include "bluetooth_connection.h"
#include "wificonnect.h"
#define START_TIME millis()

// for user questionnaire -----------------
boolean questionnaire_is_complete = false;
void runQuestionnaire();

// timers
int timer = millis() + GENERAL_FREQUENCY;
int timer_fallcheck = millis() + FALL_FREQUENCY;
int timer_dispense = millis() + 75000;
int val = 1;

void setup()
{
  // Code to run only once:
  // Setup printing
  Serial.begin(9600);
  // Weight sensor setup
  // setupWeightSensors();
  // Lights setup
  // setupLights();

  // Buzzer setup
  // setupBuzzer();

  // Photosensor setup
  // setupPhotosensor();
  // Humidity sensor setup
  // setupHumiditySensor();
  // ask initial user questions here:
  // Servo Setup
  // setUpServo();
  // setupGyro();

  // questionnaire setup
  setupBluetooth();
  setupDisplay();

  // wifi setup
  setupWifi();
}

void loop()
{
  // oneTimeQuestionaire();
  // demoRun();
  // wifiLoop(float humidity, int resWeight, int petWeight, int age, char *breed)
  Serial.println("loop starting");
  char breed[] = "medium";
  wifiLoop(val * 3, val * 5, val * 7, val * 9, breed);
  val++;
  delay(5000);
}

void runQuestionnaire()
{
  for (int i = 1; i <= 3; i++)
  {
    askQuestion(i);
    while (getResponse(i) == '\0')
    {
      // Wait until a response is received for the current question
    }

    showResponse(i, getResponse(i));
    delay(5000);
  }
}

void oneTimeQuestionaire()
{
  // one time questionnaire -------------
  if (questionnaire_is_complete == false)
  {
    runQuestionnaire();
    questionnaire_is_complete = true;
    showComplete();
    timer_dispense = millis() + 75000;
  } // ----------------------------------
}

void demoRun()
{
  if ((millis() > timer))
  {
    // visiblityLight()
    humidityCheck();
    printWeights();
    // openServo();
    // fallCheck();
    timer = millis() + GENERAL_FREQUENCY;
  }
  if ((millis() > timer_fallcheck))
  {
    fallCheck();
    timer_fallcheck = millis() + FALL_FREQUENCY;
  }
  if ((millis() > timer_dispense))
  {
    openServo();
    timer_dispense = millis() + 75000;
  }
}

/* ---  TEST FOR SERVO ---
setUpServo();
openServo();
closeServo();

*/

/* --- TESTS FOR WEIGHT SENSORS ---
test getWeight() ------------------
Serial.println(getWeight(1));
Serial.println(getWeight(2));
delay(1000);

test printWeights() ---------------
printWeights();
-------------------------------- */

/* -------- CS 147--- Group 25 ------------
          OSCAR                   NATALI

      |\      _,,,---,,_           /^ ^\
ZZZzz /,`.-'`'    -.  ;-;;,_      / 0 0 \
     |,4-  ) )-,_. ,\ (  `'-'     /\ V /\
    '---''(_/--'  `-'\_)           / - \
                                   |    \
                                   || (__V
-----------------------------------------*/

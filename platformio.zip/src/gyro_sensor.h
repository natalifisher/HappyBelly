#include "SparkFunLSM6DSO.h"
#include "Wire.h"

void setupGyro();

void fallCheck();
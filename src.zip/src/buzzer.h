#include <Arduino.h>
#include "constants.h"
void setupBuzzer();
void activateBuzzer();
void disableBuzzer();
#include <Arduino.h>
#include "constants.h"
#include "lights.h"
#include "DHT20.h" // for humidity sensor

void setupHumiditySensor();
void humidityCheck();
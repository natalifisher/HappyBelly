#include <Arduino.h>
#include "constants.h"

void setupLights();
void blinkLight(int pin, int freq);
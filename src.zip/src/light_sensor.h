
#include <Arduino.h>
#include "constants.h"
// check photosensor reading; if below light threshold, turn on visibility light
void visiblityLight();
void setupPhotosensor();